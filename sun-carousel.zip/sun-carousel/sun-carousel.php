<?php

/*
Plugin Name: Sunshine Carousel
Plugin URI: https://github.com/rileysun/
Description: Add custom CSS & JS to any page in Wordpress!
Version: 1.0
Author: Riley Lesser
Author URI: https://sun-sys.tk
*/

include 'meta.php';
